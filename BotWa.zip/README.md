### 乂  Readme

Language :  [EN](https://github.com/neoxr/neoxr-bot/blob/master/EN.md) | [ID](https://github.com/neoxr/neoxr-bot/blob/master/ID.md)

### 乂  Premium Script v3.0.1

🏷️ Price : **Rp. 150.000 / $20.80**

**Special Features & Benefit :**
- AI & AI Image
- Chat GPT (Turbo 3.5)
- Anti Bot
- Auto Download
- Porn Detector (Only Image)
- 9 Mini Games
- Leveling & Roles
- Email Verification
- Captcha Verification
- Send Email
- Changes List Message (for user)
- Free Updates
- Bonus ApiKey 5K Request (for 2 month)

**Additional Features :**
- 🏷️ Price : **+Rp. 50.000 / +$6.80**
Temporary Bot Features (Jadibot)
- 🏷️ Price : **+Rp. 35.000 / +$5.80**
Storage (Save All Media)
- 🏷️ Price : **+Rp. 30.000 / +$4.80**
Chatroom (Conversation w Bot)
- 🏷️ Price : **+Rp. 15.000 / +$3.80**
Menfess (Confess)
- 🏷️ Price : **+Rp. 10.000 / +$2.80**
Ban WhatsApp (Logout WA)

**Requirement :**
- NodeJS v14
- FFMPEG
- Ram Min. 1GB
- WhatsApp Original

Demo : [neoxr-bot v3.0.1](https://wa.me/6285723215364?text=menu)
<br>
Creator : [Wildan Izzudin](https://wa.me/6285887776722)
<br>
Official Group : [Chatbot](https://chat.whatsapp.com/Dqb7Z2G5mqnIPSc6xbVWuH)

### 乂  Documentation

You can see the documentation for using the messaging function [Here](https://github.com/neoxr/neoxr-bot/blob/master/DOCS.md).

### 乂  License
Copyright (c) 2022 Neoxr . Licensed under the [GNU GPLv3](https://github.com/neoxr/neoxr-bot/blob/master/LICENSE)